if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell "-File `"$PSCommandPath`"" -Verb RunAs; Exit
}

New-BurntToastNotification -Text 'Utilities: Organise','Initialising Structured Index' -AppLogo "$env:APPDATA\Utilities\Shell\support.ico"

$base = $Home
$desktop = "$base\Desktop"
$misc = "$desktop\Misc"

# 1. Restore Misc contents to Desktop (Loose files only)
if (Test-Path $misc) {
    Get-ChildItem $misc -File | Move-Item -Destination $desktop -Force -ErrorAction SilentlyContinue
    Remove-Item $misc -Recurse -Force -ErrorAction SilentlyContinue
}

# 2. Define Organization Map
$map = @{}
@('docx','doc') | ForEach-Object { $map[$_] = "$base\Documents\Word" }
@('xlsx', 'xls')        | ForEach-Object { $map[$_] = "$base\Documents\Excel" }
@('pptx')        | ForEach-Object { $map[$_] = "$base\Documents\PowerPoint" }
@('pdf')         | ForEach-Object { $map[$_] = "$base\Documents\PDFs" }
@('txt')         | ForEach-Object { $map[$_] = "$base\Documents\Text" }
@('bat','cmd','ps1') | ForEach-Object { $map[$_] = "$base\Documents\Scripts" }
@('exe','msi','msixbundle','appxbundle') | ForEach-Object { $map[$_] = "$base\Documents\Installers" }
@('zip','rar','7z','tar','gz','bz2','xz') | ForEach-Object { $map[$_] = "$base\Downloads\Compressed Files" }
@('png','jpg','jpeg','bmp','gif','tiff','webp') | ForEach-Object { $map[$_] = "$base\Pictures" }
@('mp3','wav','flac','aac','ogg','m4a') | ForEach-Object { $map[$_] = "$base\Music" }
@('mp4','avi','mov','mkv','flv','webm','wmv') | ForEach-Object { $map[$_] = "$base\Videos" }
# Additional filters can be added here as needed in any future versions and/or implementations.

# 3. Process Folders (Strictly loose files in root only)
$sourceFolders = "Desktop","Desktop\Misc","Downloads","Documents","Pictures","Music","Videos"

foreach ($folderName in $sourceFolders) {
    $srcPath = Join-Path $base $folderName
    if (-not (Test-Path $srcPath)) { continue }

    # Get-ChildItem without -Recurse ensures only loose files are grabbed
    Get-ChildItem $srcPath -File | ForEach-Object {
        $ext = $_.Extension.Trim('.').ToLower()
        if ($map.ContainsKey($ext)) {
            $dest = $map[$ext]
            if (-not (Test-Path $dest)) { New-Item $dest -Type Directory -Force | Out-Null }
            Move-Item $_.FullName -Destination $dest -Force -ErrorAction SilentlyContinue
        }
    }
}

# 4. Cleanup Desktop: Move remaining loose files to Misc (excluding shortcuts)
if (-not (Test-Path $misc)) { New-Item $misc -Type Directory -Force | Out-Null }
Get-ChildItem $desktop -File | Where-Object { $_.Extension -notmatch 'lnk|url' } | 
    Move-Item -Destination $misc -Force -ErrorAction SilentlyContinue

# 5. Global Cleanup: Remove empty subdirectories recursively without prompting
foreach ($folderName in $sourceFolders) {
    $target = Join-Path $base $folderName
    if (Test-Path $target) {
        Get-ChildItem $target -Recurse -Directory | 
            Sort-Object FullName -Descending | 
            Where-Object { (Get-ChildItem $_.FullName -Force).Count -eq 0 } | 
            Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# Final check: Remove Misc if empty
if (Test-Path $misc) {
    if ((Get-ChildItem $misc).Count -eq 0) { Remove-Item $misc -Recurse -Force }
}

Clear-Host
New-BurntToastNotification -Text 'Utilities: Organise','The system is now tidy!' -AppLogo "$env:APPDATA\Utilities\Shell\support.ico"
Start-Sleep -Seconds 2
exit