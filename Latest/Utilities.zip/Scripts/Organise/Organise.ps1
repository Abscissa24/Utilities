if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell "-File `"$PSCommandPath`"" -Verb RunAs; Exit
}

$toast   = "$env:APPDATA\Utilities\Shell\toast.ps1"
$icon    = "$env:APPDATA\Utilities\Shell\Utilities.ico"
$base    = $Home
$desktop = "$base\Desktop"
$misc    = "$desktop\Misc"

& $toast -Title "Utilities" -Message "Organising..." -IconPath $icon

# ── Restore Misc to Desktop ───────────────────────────────────────────────────
if (Test-Path $misc) {
    Get-ChildItem $misc -File | Move-Item -Destination $desktop -Force -ErrorAction SilentlyContinue
    Remove-Item $misc -Recurse -Force -ErrorAction SilentlyContinue
}

# ── Organisation Map ──────────────────────────────────────────────────────────
$map = @{}
$rules = @{
    "$base\Documents\Word"                = @('docx','doc')
    "$base\Documents\Excel"               = @('xlsx','xls')
    "$base\Documents\PowerPoint"          = @('pptx','ppt')
    "$base\Documents\PDFs"                = @('pdf')
    "$base\Documents\Text"                = @('txt','md','csv')
    "$base\Documents\Scripts"             = @('bat','cmd','ps1','py','sh')
    "$base\Documents\Installers"          = @('exe','msi','msixbundle','appxbundle')
    "$base\Downloads\Compressed Files"    = @('zip','rar','7z','tar','gz','bz2','xz')
    "$base\Pictures"                      = @('png','jpg','jpeg','bmp','gif','tiff','webp','ico','svg')
    "$base\Music"                         = @('mp3','wav','flac','aac','ogg','m4a','wma')
    "$base\Videos"                        = @('mp4','avi','mov','mkv','flv','webm','wmv','m4v')
}
foreach ($dest in $rules.Keys) {
    foreach ($ext in $rules[$dest]) { $map[$ext] = $dest }
}

# ── Process Loose Files ───────────────────────────────────────────────────────
foreach ($folder in @("Desktop","Desktop\Misc","Downloads","Documents","Pictures","Music","Videos")) {
    $src = Join-Path $base $folder
    if (-not (Test-Path $src)) { continue }
    Get-ChildItem $src -File | ForEach-Object {
        $ext = $_.Extension.TrimStart('.').ToLower()
        if ($map.ContainsKey($ext)) {
            $dest = $map[$ext]
            if (-not (Test-Path $dest)) { New-Item $dest -ItemType Directory -Force | Out-Null }
            Move-Item $_.FullName -Destination $dest -Force -ErrorAction SilentlyContinue
        }
    }
}

# ── Move Remaining Desktop Files to Misc ─────────────────────────────────────
New-Item $misc -ItemType Directory -Force | Out-Null
Get-ChildItem $desktop -File | Where-Object { $_.Extension -notmatch 'lnk|url' } |
    Move-Item -Destination $misc -Force -ErrorAction SilentlyContinue

# ── Remove Empty Directories ──────────────────────────────────────────────────
foreach ($folder in @("Desktop","Downloads","Documents","Pictures","Music","Videos")) {
    $target = Join-Path $base $folder
    if (-not (Test-Path $target)) { continue }
    Get-ChildItem $target -Recurse -Directory |
        Sort-Object FullName -Descending |
        Where-Object { (Get-ChildItem $_.FullName -Force).Count -eq 0 } |
        Remove-Item -Force -ErrorAction SilentlyContinue
}

# ── Remove Misc if Empty ──────────────────────────────────────────────────────
if ((Test-Path $misc) -and (Get-ChildItem $misc).Count -eq 0) {
    Remove-Item $misc -Recurse -Force
}

& $toast -Title "Utilities" -Message "Organised!" -IconPath $icon
Exit
