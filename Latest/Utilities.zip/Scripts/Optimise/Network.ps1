if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell "-File `"$PSCommandPath`"" -Verb RunAs; Exit
}

& "$env:AppData\Utilities\Shell\toast.ps1" -Title "Utilities" -Message "Optimised Network" -IconPath "$env:AppData\Utilities\Shell\Utilities.ico"

netsh int ip reset                                      *>$null
ipconfig /flushdns                                      *>$null
ipconfig /release                                       *>$null
ipconfig /renew                                         *>$null
netsh interface ipv6 set teredo disabled                *>$null
netsh interface tcp set global autotuninglevel=normal   *>$null
netsh interface tcp set global ecncapability=enabled    *>$null
netsh interface tcp set global windowsize=initial       *>$null
netsh interface tcp set global timewaitdelay=30         *>$null
netsh interface ipv4 set global rss=enabled             *>$null
netsh interface ipv6 set global rss=enabled             *>$null

Exit
