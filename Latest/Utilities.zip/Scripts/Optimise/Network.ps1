if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell "-File `"$PSCommandPath`"" -Verb RunAs
    Exit
}

New-BurntToastNotification -Text 'Utilities: Optimise Network','The network has been optimised!' -AppLogo "$env:APPDATA\Utilities\Shell\support.ico"

# Run network commands silently
& {
    netsh int ip reset
    ipconfig /flushdns
    ipconfig /release
    ipconfig /renew
    netsh interface ipv6 set teredo disabled
    netsh interface tcp set global autotuninglevel=normal
    netsh interface tcp set global ecncapability=enabled
    netsh interface tcp set global windowsize=initial
    netsh interface tcp set global timewaitdelay=30
    netsh interface ipv4 set global rss=enabled
    netsh interface ipv6 set global rss=enabled
} *>$null

Clear-Host
Exit