# Admin Check/Elevation
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell.exe "-WindowStyle Hidden -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

$ErrorActionPreference = "SilentlyContinue"

# System Cleanup
cleanmgr /sagerun:1
Remove-Item -Path "C:\Windows\Prefetch\*", "$env:LOCALAPPDATA\Microsoft\Windows\DirectX\*" -Force -Recurse
Remove-Item -Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Accessories\*", "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Administrative Tools\*" -Force -Recurse

# Temp Folders
$TempPaths = @("$env:SystemRoot\Temp", "$env:TEMP", "$env:LOCALAPPDATA\Temp")
foreach ($Path in $TempPaths) {
    takeown /f $Path /r /d y
    icacls $Path /grant "${env:USERNAME}:F" /t /c
    Remove-Item -Path "$Path\*" -Recurse -Force
}
Start-Sleep -Seconds 5
New-BurntToastNotification -Text 'Utilities: Optimise System','The system has been cleaned!' -AppLogo "$env:APPDATA\Utilities\Shell\support.ico"
Exit