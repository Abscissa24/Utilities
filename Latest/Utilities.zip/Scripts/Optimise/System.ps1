if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell.exe "-WindowStyle Hidden -File `"$PSCommandPath`"" -Verb RunAs; Exit
}

$ErrorActionPreference = "SilentlyContinue"

# ── Disk Cleanup ──────────────────────────────────────────────────────────────
cleanmgr /sagerun:1

# ── Junk Files ────────────────────────────────────────────────────────────────
Remove-Item -Force -Recurse -Path @(
    "C:\Windows\Prefetch\*"
    "C:\Windows\SoftwareDistribution\Download\*"
    "C:\Windows\Logs\*"
    "C:\Windows\Minidump\*"
    "C:\Windows\memory.dmp"
    "$env:LOCALAPPDATA\Microsoft\Windows\DirectX\*"
    "$env:LOCALAPPDATA\Microsoft\Windows\INetCache\*"
    "$env:LOCALAPPDATA\Microsoft\Windows\WebCache\*"
    "$env:LOCALAPPDATA\Microsoft\Windows\History\*"
    "$env:LOCALAPPDATA\CrashDumps\*"
    "$env:APPDATA\Microsoft\Windows\Recent\*"
    "$env:APPDATA\Microsoft\Windows\Recent\AutomaticDestinations\*"
    "$env:APPDATA\Microsoft\Windows\Recent\CustomDestinations\*"
    "C:\ProgramData\Microsoft\Windows\WER\ReportArchive\*"
    "C:\ProgramData\Microsoft\Windows\WER\ReportQueue\*"
    "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Accessories\*"
    "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Administrative Tools\*"
)

# ── Temp Folders ──────────────────────────────────────────────────────────────
foreach ($Path in @("$env:SystemRoot\Temp", "$env:TEMP", "$env:LOCALAPPDATA\Temp")) {
    takeown /f $Path /r /d y *>$null
    icacls $Path /grant "${env:USERNAME}:F" /t /c *>$null
    Remove-Item -Path "$Path\*" -Recurse -Force
}

# ── Browser Caches ────────────────────────────────────────────────────────────
Stop-Process -Name "brave", "chrome", "msedge", "firefox" -Force

$BrowserCaches = @(
    "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Cache"
    "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Code Cache"
    "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache"
    "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Code Cache"
    "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache"
    "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Code Cache"
    "$env:APPDATA\Mozilla\Firefox\Profiles"
)

foreach ($Path in $BrowserCaches) {
    if (Test-Path $Path) {
        Remove-Item -Path "$Path\*" -Recurse -Force
    }
}

# ── Windows Update Cleanup ────────────────────────────────────────────────────
Stop-Service -Name wuauserv -Force
Remove-Item -Force -Recurse -Path "C:\Windows\SoftwareDistribution\*"
Start-Service -Name wuauserv

# ── Event Logs ────────────────────────────────────────────────────────────────
Get-EventLog -List | ForEach-Object { Clear-EventLog $_.Log }

# ── Memory Standby List ───────────────────────────────────────────────────────
if (Get-Command RAMMap -ErrorAction SilentlyContinue) {
    RAMMap -Ew
}

# ── Recycle Bin ───────────────────────────────────────────────────────────────
# Clear-RecycleBin -Force

# ── Thumbnail Cache ───────────────────────────────────────────────────────────
Stop-Process -Name explorer -Force
Remove-Item -Force -Recurse -Path "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\thumbcache_*.db"
Start-Process explorer.exe

# ── System File Check ─────────────────────────────────────────────────────────
# sfc /scannow *>$null

# ── DISM Component Cleanup ────────────────────────────────────────────────────
# dism /Online /Cleanup-Image /StartComponentCleanup /ResetBase *>$null

# ── Defrag (SSD-aware) ───────────────────────────────────────────────────────
$drive = Get-PhysicalDisk | Where-Object { $_.DeviceId -eq 0 }
if ($drive.MediaType -eq "HDD") {
    defrag C: /U /V *>$null
} else {
    defrag C: /L *>$null
}

& "$env:AppData\Utilities\Shell\toast.ps1" -Title "Utilities" -Message "System Optimised" -IconPath "$env:AppData\Utilities\Shell\Utilities.ico"
