if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell "-File `"$PSCommandPath`"" -Verb RunAs; Exit
}

$ini     = "$env:AppData\Utilities\Insomnia\Insomnia.ini"
$toast   = "$env:AppData\Utilities\Shell\toast.ps1"
$icon    = "$env:AppData\Utilities\Shell\Utilities.ico"

function Set-PowerConfig($standby, $monitor, $disk, $lidAC, $lidDC) {
    powercfg -change standby-timeout-ac $standby
    powercfg -change standby-timeout-dc $standby
    powercfg -change monitor-timeout-ac $monitor
    powercfg -change monitor-timeout-dc $monitor
    powercfg -change disk-timeout-ac    $disk
    powercfg -change disk-timeout-dc    $disk
    powercfg /setacvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION $lidAC
    powercfg /setdcvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION $lidDC
}

if (Test-Path $ini) {
    & $toast -Title "Insomnia Mode" -Message "Deactivated" -IconPath $icon
    Set-PowerConfig 3 3 3 1 2
    Remove-Item $ini -Force -ErrorAction SilentlyContinue
} else {
    & $toast -Title "Insomnia Mode" -Message "Activated" -IconPath $icon
    Set-PowerConfig 0 0 0 0 0
    New-Item -Path (Split-Path $ini) -ItemType Directory -Force | Out-Null
    New-Item -Path $ini -ItemType File -Force | Out-Null
}

Start-Sleep -Seconds 1
Exit
