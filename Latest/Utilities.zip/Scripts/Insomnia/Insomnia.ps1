if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell "-File `"$PSCommandPath`"" -Verb RunAs
    Exit
}

$iniPath = "$env:AppData\Utilities\Insomnia\Insomnia.ini"

if (Test-Path $iniPath) {
    New-BurntToastNotification -Text 'Utilities: Insomnia','Status: ON' -AppLogo "$env:APPDATA\Utilities\Shell\support.ico"
    powercfg -change standby-timeout-ac 0
    powercfg -change standby-timeout-dc 0
    powercfg /setacvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 0
    powercfg /setdcvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 0
    powercfg -change monitor-timeout-ac 0
    powercfg -change monitor-timeout-dc 0
    powercfg -change disk-timeout-ac 0
    powercfg -change disk-timeout-dc 0
    
    Start-Sleep -Seconds 1
    Remove-Item $iniPath -Force -ErrorAction SilentlyContinue
} else {
    New-BurntToastNotification -Text 'Utilities: Insomnia','Status: OFF' -AppLogo "$env:APPDATA\Utilities\Shell\support.ico"
    New-Item -Path (Split-Path $iniPath) -ItemType Directory -Force | Out-Null
    Robocopy "C:\Utilities\Scripts\Insomnia" (Split-Path $iniPath) "Insomnia.ini" /njh /njs /ndl /nc /ns

    powercfg -change standby-timeout-ac 3
    powercfg -change standby-timeout-dc 3
    powercfg /setacvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 1
    powercfg /setdcvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 2
    powercfg -change monitor-timeout-ac 3
    powercfg -change monitor-timeout-dc 3
    powercfg -change disk-timeout-ac 3
    powercfg -change disk-timeout-dc 3

    Start-Sleep -Seconds 1
}

Clear-Host
Exit