@echo off

COLOR 02
call "C:\Utilities\Data\Speedtest\speedtest.exe"

pause /nobreak >nul