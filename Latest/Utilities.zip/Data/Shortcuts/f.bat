@echo off
cls
fastfetch
echo. 
pause