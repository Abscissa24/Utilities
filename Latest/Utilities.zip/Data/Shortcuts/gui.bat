@echo off
cls
echo Fetching latest GUI
powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/Abscissa24/Utilities/releases/download/GUI/Utilities.exe' -OutFile '%USERPROFILE%\Desktop\Utilities.exe' -UseBasicParsing" >nul 2>&1
timeout /t 1 /nobreak >nul 2>&1
cls
start "" "%USERPROFILE%\Desktop\Utilities.exe"
goto MAIN_MENU