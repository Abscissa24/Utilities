@echo off
setlocal enabledelayedexpansion

NET SESSION >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    powershell -Command "Start-Process '%~s0' -Verb runAs"
    exit /b
)

reg delete "HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" /f
reg add "HKCR\Directory\Background\shellex\ContextMenuHandlers\New" /ve /d "{D969A300-E7FF-11d0-A93B-00A0C90F2719}" /f
timeout /t 2 /nobreak
taskkill /f /im explorer.exe && start explorer.exe

exit /b


