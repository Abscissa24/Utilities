@echo off
setlocal enabledelayedexpansion

:: Check for admin rights
NET SESSION >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    powershell -Command "Start-Process '%~s0' -Verb runAs"
    exit /b
)

title Repairing APPDATA

COLOR 03
set "UTILITIES_URL=https://github.com/Abscissa24/Utilities/raw/main"
set "TEMP_DIR=%SystemRoot%\Temp"
set "INSTALL_DIR=C:\Utilities"
set "SHELL_DIR=C:\Program Files\Nilesoft Shell"

:MAIN_MENU
COLOR 03
cls

:: Configuration Settings

if not exist "%Appdata%\Utilities\Setup\Setup.bat" (
    cls
    echo Configuring
    mkdir "%Appdata%\Utilities\Setup"
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/Abscissa24/Utilities/releases/download/Rolling-Release/Setup.bat' -OutFile '%Appdata%\Utilities\Setup\Setup.bat' -UseBasicParsing" >nul 2>&1
)

if not exist "%Appdata%\Utilities\Shell\Support.ico" (
    cls
    mkdir "%Appdata%\Utilities\Shell"
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/Abscissa24/Utilities/raw/refs/heads/main/Assets/support.ico' -OutFile '%Appdata%\Utilities\Shell\support.ico' -UseBasicParsing" >nul 2>&1
)

if not exist "%Appdata%\Utilities\Figlet\figlet.exe" (
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%UTILITIES_URL%/Assets/FLGlet.zip' -OutFile '%TEMP_DIR%\FLGlet.zip' -UseBasicParsing" >nul 2>&1
    powershell -Command "Expand-Archive -Path '%TEMP_DIR%\FLGlet.zip' -DestinationPath '%Appdata%\Utilities\Figlet' -Force" >nul 2>&1
    del "%TEMP_DIR%\FLGlet.zip" >nul 2>&1
)

if not exist "%Appdata%\Utilities\Themes" (
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%UTILITIES_URL%/Assets/Themes.zip' -OutFile '%TEMP_DIR%\Themes.zip' -UseBasicParsing" >nul 2>&1
    powershell -Command "Expand-Archive -Path '%TEMP_DIR%\Themes.zip' -DestinationPath '%Appdata%\Utilities\Themes' -Force" >nul 2>&1
    del "%TEMP_DIR%\Themes.zip" >nul 2>&1
)

if exist "%Appdata%\Utilities\Figlet\figlet.exe" (
    cd /d "%Appdata%\Utilities\Figlet"
    figlet Success
    echo.
)

timeout /t 2 >nul 2>&1
exit /b