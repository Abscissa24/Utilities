Write-Host('Cleaning Up') -Fore Green
Write-Host('***********') -Fore Green

Get-ChildItem -Path "C:\Windows\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
Get-ChildItem -Path "C:\Users\mawzes\AppData\Local\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue

Write-Host('Success!') -Fore Green
Start-Sleep -Seconds 2
