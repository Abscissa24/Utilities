﻿Write-Host('Organising Data Structure') -Fore Green
Write-Host(' ')
Start-Sleep -Seconds 2

#Organising Folder Structure
robocopy C:\Users\moosa\Downloads C:\Windows\Temp /S /MOVE
robocopy C:\Users\moosa\Desktop C:\Windows\Temp /S /MOVE
robocopy C:\Users\moosa\Videos C:\Windows\Temp /S /MOVE
robocopy C:\Users\moosa\Music C:\Windows\Temp /S /MOVE
robocopy C:\Users\moosa\Pictures C:\Windows\Temp /S /MOVE
robocopy C:\Users\moosa\Documents C:\Windows\Temp /S /MOVE

Start-Sleep -Seconds 2
Remove-Item -Path "C:\Users\moosa\Desktop" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\moosa\Downloads" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\moosa\Pictures" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\moosa\Videos" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\moosa\Documents" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\moosa\Music" -Recurse -Force -ErrorAction SilentlyContinue

#Organising File Structure (Pictures)
robocopy C:\Windows\Temp C:\Users\moosa\Pictures *.jpg *.png *.gif *.tiff *.jpeg *.heic *.heif /S /MOVE
Start-Sleep -Seconds 2

#Organising File Structure (Videos)
robocopy C:\Windows\Temp C:\Users\moosa\Videos *.mkv *.mov *.mp4 *.hevc /S /MOVE
Start-Sleep -Seconds 2

#Organising File Structure (Documents)
robocopy C:\Windows\Temp C:\Users\moosa\Documents *.xlsx *.txt *.doc *.docx *.pptx *.pdf /S /MOVE
Start-Sleep -Seconds 2

#Organising File Structure (Music)
robocopy C:\Windows\Temp C:\Users\moosa\Music *.mp3 *.wav *.flac *.aac *.m4a /S /MOVE
Start-Sleep -Seconds 2

#Organising File Structure (Shortcuts)
robocopy C:\Windows\Temp C:\Users\moosa\Desktop *.lnk /S /MOVE
Start-Sleep -Seconds 2

#Organising File Structure (Software)
robocopy C:\Windows\Temp C:\Users\moosa\Downloads\Software *.exe *.msi *.msix *.msixbundle /S /MOVE
Start-Sleep -Seconds 2

#Organising File Structure (Downloads)
robocopy C:\Windows\Temp C:\Users\moosa\Downloads\Misc /S /MOVE
Remove-Item -Path C:\Users\moosa\Downloads\Misc\Misc -Recurse -Force -ErrorAction SilentlyContinue

Start-Sleep -Seconds 2

New-Item -Path "C:\Users\moosa" -Name "Desktop" -ItemType Directory -ErrorAction SilentlyContinue

#Flush Caches
Get-ChildItem -Path "C:\Windows\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
Get-ChildItem -Path "C:\Users\moosa\AppData\Local\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue