﻿Write-Host('System Backup
') -Fore Green

#Local Backup
Copy-Item -Path C:\Users\mawzes\Desktop -Destination C:\Windows\Utilities\Data\Backup\Local\Desktop -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Users\mawzes\Documents -Destination C:\Windows\Utilities\Data\Backup\Local -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Users\mawzes\Downloads -Destination C:\Windows\Utilities\Data\Backup\Local -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Users\mawzes\Music -Destination C:\Windows\Utilities\Data\Backup\Local -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Users\mawzes\Pictures -Destination C:\Windows\Utilities\Data\Backup\Local -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Users\mawzes\Videos -Destination C:\Windows\Utilities\Data\Backup\Local -Recurse -Force -ErrorAction SilentlyContinue

Start-Sleep -Seconds 2

#Flush Caches
Get-ChildItem -Path "C:\Windows\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
Get-ChildItem -Path "C:\Users\mawzes\AppData\Local\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue

robocopy C:\Windows\Utilities\Data\Backup\Local C:\Windows\Temp /S /MOVE
Start-Sleep -Seconds 2
robocopy C:\Windows\Temp "S:\mawzes\Backup\Local" /S /MOVE

#Flush Caches
Get-ChildItem -Path "C:\Windows\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue