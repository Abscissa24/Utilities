﻿Write-Host('System Restore
') -Fore Green

#Flush Caches
Get-ChildItem -Path "C:\Windows\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
Get-ChildItem -Path "C:\Users\mawzes\AppData\Local\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue

#Local Restore

robocopy "S:\Mawzes\Backup\Local" C:\Windows\Temp /S

Copy-Item -Path C:\Windows\Temp\Desktop -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Windows\Temp\Documents -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Windows\Temp\Downloads -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Windows\Temp\Music -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Windows\Temp\Pictures -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Windows\Temp\Videos -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue

#Flush Caches
Get-ChildItem -Path "C:\Windows\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue