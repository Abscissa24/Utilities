﻿Write-Host('System Restore
') -Fore Green

#Wallpaper Restore
Get-ChildItem -Path "C:\Windows\Utilities\Data\Backup\Wallpaper\*" -Include *.jpg,* -Recurse | Copy-Item -Destination C:\Windows\Web\Wallpaper\Windows -Force -Recurse

#Themes Restore
Remove-Item -Path "C:\Windows\Resources\Themes" -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Windows\Utilities\Data\Backup\Themes -Destination C:\Windows\Resources\ -Recurse -Force

#Remove Custom Themes
Invoke-Item C:\Windows\Resources\Themes\aero.theme
Start-Sleep -Seconds 2; Stop-process -name SystemSettings
Remove-Item -Path "C:\Users\mawzes\AppData\Local\Microsoft\Windows\Themes" -Recurse -Force -ErrorAction SilentlyContinue

#Desktop Configuration
$desktop_icons =
[pscustomobject]@{
    Path  = "Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel"
    Value = 1
    Name = "{20D04FE0-3AEA-1069-A2D8-08002B30309D}"
    Description = "This PC"
},
[pscustomobject]@{
    Path  = "Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel"
    Value = 0
    Name = "{645FF040-5081-101B-9F08-00AA002F954E}"
    Description = "Recycle Bin"
} | group Path

foreach($setting in $desktop_icons){
    $registry = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($setting.Name, $true)
    if ($null -eq $registry) {
        $registry = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($setting.Name, $true)
    }
    $setting.Group | %{
        $registry.SetValue($_.name, $_.value)
    }
    $registry.Dispose()
}

#Reverting Organisation Scheme
Remove-Item -Path "C:\Users\mawzes\Desktop" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\mawzes\Downloads" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\mawzes\Pictures" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\mawzes\Videos" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\mawzes\Documents" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\mawzes\Music" -Recurse -Force -ErrorAction SilentlyContinue

#Local Restore

robocopy "S:\mawzes's Laptop\Backup\Local" C:\Windows\Temp /S

Copy-Item -Path C:\Windows\Temp\Desktop -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Windows\Temp\Documents -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Windows\Temp\Downloads -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Windows\Temp\Music -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Windows\Temp\Pictures -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item -Path C:\Windows\Temp\Videos -Destination C:\Users\mawzes -Recurse -Force -ErrorAction SilentlyContinue

#Flush Caches
Get-ChildItem -Path "C:\Windows\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
Get-ChildItem -Path "C:\Users\mawzes\AppData\Local\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue

#Show Supplementary Themes
attrib -s -h C:\Windows\Resources\Themes

#Remove Mica Shell
Invoke-Item C:\ProgramData\PhoenixOS\Apps\Acrylic\uninstall.cmd
Start-Sleep -Seconds 0.6
Stop-process -name RegSvr32

#Flush Caches
Get-ChildItem -Path "C:\Windows\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
Get-ChildItem -Path "C:\Users\mawzes\AppData\Local\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue