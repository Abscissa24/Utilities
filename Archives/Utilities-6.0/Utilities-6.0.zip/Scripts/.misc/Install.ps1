﻿Write-Host('Configuring System
') -Fore Green

#Create Restore Point
Enable-ComputerRestore -Drive "C:\"
Start-Sleep -Seconds 1
Checkpoint-Computer -Description "Clean Install" -RestorePointType MODIFY_SETTINGS

#Wallpaper Backup
Get-ChildItem -Path "C:\Windows\Web\Wallpaper\Windows\*" -Include *.jpg,* -Recurse | Copy-Item -Destination C:\Windows\Utilities\Data\Backup\Wallpaper -Force

#Themes Backup
Copy-Item -Path C:\Windows\Resources\Themes -Destination C:\Windows\Utilities\Data\Backup -Recurse -Force

#Flush Caches
Get-ChildItem -Path "C:\Windows\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
Get-ChildItem -Path "C:\Users\mawzes\AppData\Local\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue

#Clean Start Menu
Remove-Item -Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\mawzes\AppData\Roaming\Microsoft\Windows\Start Menu\Programs" -Recurse -Force -ErrorAction SilentlyContinue
New-Item -Path "C:\Users\mawzes\AppData\Roaming\Microsoft\Windows\Start Menu\Programs" -Name "Startup" -ItemType Directory
New-Item -Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs" -Name "Startup" -ItemType Directory

#Organising Folder Structure
robocopy C:\Users\mawzes\Downloads C:\Windows\Temp /S /MOVE
robocopy C:\Users\mawzes\Desktop C:\Windows\Temp /S /MOVE
robocopy C:\Users\mawzes\Videos C:\Windows\Temp /S /MOVE
robocopy C:\Users\mawzes\Music C:\Windows\Temp /S /MOVE
robocopy C:\Users\mawzes\Pictures C:\Windows\Temp /S /MOVE
robocopy C:\Users\mawzes\Documents C:\Windows\Temp /S /MOVE

Start-Sleep -Seconds 2
Remove-Item -Path "C:\Users\mawzes\Desktop" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\mawzes\Downloads" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\mawzes\Pictures" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\mawzes\Videos" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\mawzes\Documents" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "C:\Users\mawzes\Music" -Recurse -Force -ErrorAction SilentlyContinue

#Organising File Structure (Pictures)
robocopy C:\Windows\Temp C:\Users\mawzes\Pictures *.jpg *.png *.gif *.tiff *.jpeg *.heic *.heif /S /MOVE
Start-Sleep -Seconds 2

#Organising File Structure (Videos)
robocopy C:\Windows\Temp C:\Users\mawzes\Videos *.mkv *.mov *.mp4 *.hevc /S /MOVE
Start-Sleep -Seconds 2

#Organising File Structure (Documents)
robocopy C:\Windows\Temp C:\Users\mawzes\Documents *.xlsx *.txt *.doc *.docx *.pptx *.pdf /S /MOVE
Start-Sleep -Seconds 2

#Organising File Structure (Music)
robocopy C:\Windows\Temp C:\Users\mawzes\Music *.mp3 *.wav *.flac *.aac *.m4a /S /MOVE
Start-Sleep -Seconds 2

#Organising File Structure (Shortcuts)
robocopy C:\Windows\Temp C:\Users\mawzes\Desktop *.lnk /S /MOVE
Start-Sleep -Seconds 2

#Organising File Structure (Downloads)
robocopy C:\Windows\Temp C:\Users\mawzes\Downloads\Misc /S /MOVE
Remove-Item -Path C:\Users\mawzes\Downloads\Misc\Misc -Recurse -Force -ErrorAction SilentlyContinue

Start-Sleep -Seconds 2

New-Item -Path "C:\Users\mawzes" -Name "Desktop" -ItemType Directory

#Flush Caches
Get-ChildItem -Path "C:\Windows\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
Get-ChildItem -Path "C:\Users\mawzes\AppData\Local\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue

#Desktop Configuration
$desktop_icons =
[pscustomobject]@{
    Path  = "Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel"
    Value = 0
    Name = "{20D04FE0-3AEA-1069-A2D8-08002B30309D}"
    Description = "This PC"
},
[pscustomobject]@{
    Path  = "Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel"
    Value = 1
    Name = "{645FF040-5081-101B-9F08-00AA002F954E}"
    Description = "Recycle Bin"
} | group Path

foreach($setting in $desktop_icons){
    $registry = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($setting.Name, $true)
    if ($null -eq $registry) {
        $registry = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($setting.Name, $true)
    }
    $setting.Group | %{
        $registry.SetValue($_.name, $_.value)
    }
    $registry.Dispose()
}

#Hide Supplementary Themes
attrib +h C:\Windows\Resources\Themes

#Inject Custom Theme
Invoke-Item 'C:\Windows\Utilities\Plugins\Themes\Light Clouds\Light Clouds.deskthemepack'
Start-Sleep -Seconds 2; Stop-process -name SystemSettings
Invoke-Item 'C:\Windows\Utilities\Plugins\Themes\Dark Blossom\Dark Blossom.deskthemepack'
Start-Sleep -Seconds 2; Stop-process -name SystemSettings

#Power Plan
powercfg -import "C:\Windows\Utilities\Data\Misc\Efficiency.pow"

#Configuration
regsvr32 "C:\Windows\Utilities\Plugins\Themes\Release\ExplorerBlurMica.dll"
Start-Sleep -Seconds 0.6
Stop-process -name RegSvr32

Invoke-Item C:\Windows\Utilities\Plugins\Commands\OwnershipON.bat
Invoke-Item C:\Windows\Utilities\Plugins\Commands\TaskbarOFF.cmd
Invoke-Item C:\ProgramData\PhoenixOS\FireWall\FirewallON.cmd

$filepath = "C:\Windows\Utilities\Plugins\Registry\explorer.reg"
$proc = start-process reg.exe -ArgumentList "import $filepath" -PassThru -Wait
if ($proc.ExitCode -eq 0) {
	'Success!'
}
else {
	"Fail! Exit codE: $($Proc.ExitCode)"
}

$filepath = "C:\Windows\Utilities\Plugins\Registry\hide.reg"
$proc = start-process reg.exe -ArgumentList "import $filepath" -PassThru -Wait
if ($proc.ExitCode -eq 0) {
	'Success!'
}
else {
	"Fail! Exit codE: $($Proc.ExitCode)"
}

$filepath = "C:\Windows\Utilities\Plugins\Registry\gallery.reg"
$proc = start-process reg.exe -ArgumentList "import $filepath" -PassThru -Wait
if ($proc.ExitCode -eq 0) {
	'Success!'
}
else {
	"Fail! Exit codE: $($Proc.ExitCode)"
}

$filepath = "C:\Windows\Utilities\Plugins\Registry\mobile.reg"
$proc = start-process reg.exe -ArgumentList "import $filepath" -PassThru -Wait
if ($proc.ExitCode -eq 0) {
	'Success!'
}
else {
	"Fail! Exit codE: $($Proc.ExitCode)"
}

$filepath = "C:\Windows\Utilities\Plugins\Registry\winver.reg"
$proc = start-process reg.exe -ArgumentList "import $filepath" -PassThru -Wait
if ($proc.ExitCode -eq 0) {
	'Success!'
}
else {
	"Fail! Exit codE: $($Proc.ExitCode)"
}

#Update Drivers
$UpdateSvc = New-Object -ComObject Microsoft.Update.ServiceManager
$UpdateSvc.AddService2("7971f918-a847-4430-9279-4a52d1efe18d",7,"")
$Session = New-Object -ComObject Microsoft.Update.Session
$Searcher = $Session.CreateUpdateSearcher() 

$Searcher.ServiceID = '7971f918-a847-4430-9279-4a52d1efe18d'
$Searcher.SearchScope =  1 # MachineOnly
$Searcher.ServerSelection = 3 # Third Party
          
$Criteria = "IsInstalled=0 and Type='Driver'"
Write-Host('Updating Drivers') -Fore Green
Write-Host(' ')     
$SearchResult = $Searcher.Search($Criteria)          
$Updates = $SearchResult.Updates
if([string]::IsNullOrEmpty($Updates)){
  Write-Host('Updates Not Found!') -Fore Red
  Write-Host(' ')
}
else{
  #Show available Drivers...
  $Updates | select Title, DriverModel, DriverVerDate, Driverclass, DriverManufacturer | fl
  $UpdatesToDownload = New-Object -Com Microsoft.Update.UpdateColl
  $updates | % { $UpdatesToDownload.Add($_) | out-null }
  Write-Host('Downloading Drivers')  -Fore Green
  Write-Host(' ')
  $UpdateSession = New-Object -Com Microsoft.Update.Session
  $Downloader = $UpdateSession.CreateUpdateDownloader()
  $Downloader.Updates = $UpdatesToDownload
  $Downloader.Download()
  $UpdatesToInstall = New-Object -Com Microsoft.Update.UpdateColl
  $updates | % { if($_.IsDownloaded) { $UpdatesToInstall.Add($_) | out-null } }

  Write-Host('Installing Drivers')  -Fore Green
  Write-Host(' ')
  $Installer = $UpdateSession.CreateUpdateInstaller()
  $Installer.Updates = $UpdatesToInstall
  $InstallationResult = $Installer.Install()
  if($InstallationResult.RebootRequired) { 
  Write-Host('Reboot required!') -Fore Red
  } else { Write-Host('Done') -Fore Green
  Write-Host(' ')}
  $updateSvc.Services | ? { $_.IsDefaultAUService -eq $false -and $_.ServiceID -eq "7971f918-a847-4430-9279-4a52d1efe18d" } | % { $UpdateSvc.RemoveService($_.ServiceID) }
}

Write-Host(' ')
#Installing Chocolatey
Invoke-Item C:\Windows\Utilities\Data\Misc\choco.ps1
Start-Sleep -Seconds 5
#choco upgrade all -force -y
#choco install brave -y

Write-Host('Installing Apps')  -Fore Green
$apps = @(

    #Microsoft Store Repository
    @{name = "XP8C9QZMS2PC1T" }, #Brave Browser
    @{name = "9NKSQGP7F2NH" }, #WhatsApp
    @{name = "9WZDNCRFHVN5" }, #Windows Calculator
    @{name = "9WZDNCRFJ3PT" }, #Windows Media Player
    @{name = "9MSMLRH6LZF3" }, #Windows Notepad
    @{name = "9MZ95KL8MR0L" },  #Snipping Tool
    #Winget Repository
    @{name = "RARLab.WinRAR" }, #WinRAR
    @{name = "Valve.Steam" } #Steam

    );
    
    Foreach ($app in $apps) {
    $listApp = winget list --exact -q $app.name
    if (![String]::Join("", $listApp).Contains($app.name)) {
        Write-host " "
        Write-host "Installing: " $app.name  -Fore Green
        winget install -e -h --accept-source-agreements --accept-package-agreements --id $app.name 
    }
    else {
        Write-host " "
        Write-host "Updating Installed App: " $app.name -Fore Magenta
        Write-host " "
        winget upgrade -e -h --accept-source-agreements --accept-package-agreements --id $app.name
    }
}

Start-Sleep -Seconds 1

Write-Host(' ')
Write-Host('Installing Microsoft Office')  -Fore Green
Write-Host(' ')
cd C:\Windows\Utilities\Data\Office
.\setup.exe /configure .\Configuration.xml

Start-Sleep -Seconds 3

Write-Host('
Installing Keys') -Fore Green

#Activating WinRAR
Copy-Item -Path C:\Windows\Utilities\Plugins\Keys\Mawzes\rarreg.key -Destination 'C:\Program Files\WinRAR\rarreg.key' -Recurse -Force

#Activating Microsoft Office
& ([ScriptBlock]::Create((irm https://get.activated.win))) /Ohook

Write-Host(' ')
Write-Host('Cleaning Up') -Fore Green

#Flush Caches
Get-ChildItem -Path "C:\Windows\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
Get-ChildItem -Path "C:\Users\mawzes\AppData\Local\Temp" . -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue

Write-Host('')
Write-Host('Restarting!') -Fore Green
Start-Sleep -Seconds 5
Rename-Computer -NewName "HP-Laptop"
Restart-Computer