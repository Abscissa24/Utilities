#Use yt-dlp.exe as a proxy
$ytDlpPath = "C:\Windows\Utilities\Plugins\Misc\yt-dlp.exe"

# Function to download the video
function Download-Video {
    param (
        [string]$url
    )

    if (-not (Test-Path $ytDlpPath)) {
        Write-Output "Proxy not found at $ytDlpPath"
        return
    }

    #Use highest quality option inside the proxy container
    $arguments = @(
        "--no-check-certificate",
        "-f", "bestvideo+bestaudio/best",
        "-o", "$($env:USERPROFILE)\Downloads\%(title)s.%(ext)s",
        $url
    )

    # Execute the proxy config
    Write-Output "Downloading..."
    & $ytDlpPath $arguments
    Write-Output "The video is saved in your Downloads folder."
}

# Prompt user for video URL
$videoURL = Read-Host "Paste the link"
if ($videoURL -match "^https?://") {
    Download-Video -url $videoURL
} else {
    Write-Output "Invalid Link!"
}
