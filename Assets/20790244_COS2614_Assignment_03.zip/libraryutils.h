// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#ifndef LIBRARYUTILS_H
#define LIBRARYUTILS_H

#include <QString>
#include <QList>
#include "libraryitem.h"

// Save and load format: each line:
// Type|ID|Title|Author|GenreOrIssue|BorrowedFlag
// Example: Book|B001|The Hobbit|Tolkien|Fantasy|0

namespace LibraryUtils {
    bool saveToFile(const QString &filename, const QList<LibraryItem*> &items);
    QList<LibraryItem*> loadFromFile(const QString &filename);

    // helpers
    QString escapeField(const QString &s);
    QString unescapeField(const QString &s);
}

#endif // LIBRARYUTILS_H
