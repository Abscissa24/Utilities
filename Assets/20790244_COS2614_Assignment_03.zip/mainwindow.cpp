// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QListView>
#include <QLineEdit>
#include <QPushButton>
#include <QStandardItem>
#include "libraryutils.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), m_model(new QStandardItemModel(this)), m_proxy(new QSortFilterProxyModel(this))
{
    setupUi();
    loadData();
    refreshModel();
}

MainWindow::~MainWindow() {
    // storage destructor cleans up contained pointers
    saveData();
}

void MainWindow::setupUi()
{
    QWidget *central = new QWidget;
    setCentralWidget(central);
    QVBoxLayout *mainL = new QVBoxLayout;
    central->setLayout(mainL);

    // Top: inputs
    QHBoxLayout *inputRow = new QHBoxLayout;
    m_idEdit = new QLineEdit; m_idEdit->setPlaceholderText("ID");
    m_titleEdit = new QLineEdit; m_titleEdit->setPlaceholderText("Title");
    m_authorEdit = new QLineEdit; m_authorEdit->setPlaceholderText("Author");
    m_genreOrIssueEdit = new QLineEdit; m_genreOrIssueEdit->setPlaceholderText("Genre or IssueNumber");
    m_addBookBtn = new QPushButton("Add Book");
    m_addMagazineBtn = new QPushButton("Add Magazine");
    inputRow->addWidget(m_idEdit);
    inputRow->addWidget(m_titleEdit);
    inputRow->addWidget(m_authorEdit);
    inputRow->addWidget(m_genreOrIssueEdit);
    inputRow->addWidget(m_addBookBtn);
    inputRow->addWidget(m_addMagazineBtn);
    mainL->addLayout(inputRow);

    connect(m_addBookBtn, &QPushButton::clicked, this, &MainWindow::onAddBook);
    connect(m_addMagazineBtn, &QPushButton::clicked, this, &MainWindow::onAddMagazine);

    // Search
    QHBoxLayout *searchRow = new QHBoxLayout;
    m_searchEdit = new QLineEdit;
    m_searchEdit->setPlaceholderText("Search by title/author...");
    searchRow->addWidget(new QLabel("Search:"));
    searchRow->addWidget(m_searchEdit);
    mainL->addLayout(searchRow);
    connect(m_searchEdit, &QLineEdit::textChanged, this, &MainWindow::onSearchTextChanged);

    // List view
    m_listView = new QListView;
    m_proxy->setSourceModel(m_model);
    m_proxy->setFilterCaseSensitivity(Qt::CaseInsensitive);
    m_proxy->setFilterKeyColumn(-1); // match all columns / data
    m_listView->setModel(m_proxy);
    mainL->addWidget(m_listView);
    connect(m_listView, &QListView::activated, this, &MainWindow::onItemActivated);

    // Details and borrow/return
    QHBoxLayout *bottomRow = new QHBoxLayout;
    m_detailLabel = new QLabel("Select an item to see details");
    m_borrowReturnBtn = new QPushButton("Borrow/Return");
    bottomRow->addWidget(m_detailLabel);
    bottomRow->addWidget(m_borrowReturnBtn);
    mainL->addLayout(bottomRow);
    connect(m_borrowReturnBtn, &QPushButton::clicked, this, &MainWindow::onBorrowReturn);

    setWindowTitle("Library Management");
    resize(900, 600);
}

void MainWindow::onAddBook()
{
    QString id = m_idEdit->text().trimmed();
    QString title = m_titleEdit->text().trimmed();
    QString author = m_authorEdit->text().trimmed();
    QString genre = m_genreOrIssueEdit->text().trimmed();
    if (id.isEmpty() || title.isEmpty()) return;
    Book* b = new Book(id, title, author, genre);
    m_books.add(b);
    refreshModel();
    saveData();
}

void MainWindow::onAddMagazine()
{
    QString id = m_idEdit->text().trimmed();
    QString title = m_titleEdit->text().trimmed();
    QString author = m_authorEdit->text().trimmed();
    int issue = m_genreOrIssueEdit->text().toInt();
    if (id.isEmpty() || title.isEmpty()) return;
    Magazine* m = new Magazine(id, title, author, issue);
    m_magazines.add(m);
    refreshModel();
    saveData();
}

void MainWindow::refreshModel()
{
    m_model->clear();
    // Add books
    for (Book* b : m_books.items()) {
        QStandardItem *it = new QStandardItem(b->displayInfo());
        it->setData(QString("%1|%2").arg("Book", b->id())); // store type|id for lookup
        m_model->appendRow(it);
    }
    for (Magazine* m : m_magazines.items()) {
        QStandardItem *it = new QStandardItem(m->displayInfo());
        it->setData(QString("%1|%2").arg("Magazine", m->id()));
        m_model->appendRow(it);
    }
}

void MainWindow::onSearchTextChanged(const QString &text)
{
    // Filter by substring
    m_proxy->setFilterFixedString(text);
}

void MainWindow::onItemActivated(const QModelIndex &index)
{
    QModelIndex srcIdx = m_proxy->mapToSource(index);
    QStandardItem *item = m_model->itemFromIndex(srcIdx);
    if (!item) return;
    QString stored = item->data().toString(); // "Type|ID"
    QStringList parts = stored.split("|");
    if (parts.size() != 2) return;
    QString type = parts[0];
    QString id = parts[1];
    LibraryItem* selected = nullptr;
    if (type == "Book") selected = m_books.findById(id);
    else if (type == "Magazine") selected = m_magazines.findById(id);
    if (selected) {
        m_detailLabel->setText(selected->displayInfo());
    }
}

void MainWindow::onBorrowReturn()
{
    QModelIndex idx = m_listView->currentIndex();
    if (!idx.isValid()) return;
    QModelIndex srcIdx = m_proxy->mapToSource(idx);
    QStandardItem *item = m_model->itemFromIndex(srcIdx);
    if (!item) return;
    QString stored = item->data().toString(); // "Type|ID"
    QStringList parts = stored.split("|");
    if (parts.size() != 2) return;
    QString type = parts[0];
    QString id = parts[1];
    LibraryItem* selected = nullptr;
    if (type == "Book") selected = m_books.findById(id);
    else if (type == "Magazine") selected = m_magazines.findById(id);
    if (selected) {
        selected->setBorrowed(!selected->isBorrowed());
        refreshModel();
        saveData();
    }
}

QList<LibraryItem*> MainWindow::allLoadedItems()
{
    QList<LibraryItem*> out;
    for (Book* b : m_books.items()) out.append(b);
    for (Magazine* m : m_magazines.items()) out.append(m);
    return out;
}

void MainWindow::loadData()
{
    QList<LibraryItem*> loaded = LibraryUtils::loadFromFile(m_dataFile);
    for (LibraryItem* it : loaded) {
        if (it->typeName() == "Book") m_books.add(static_cast<Book*>(it));
        else if (it->typeName() == "Magazine") m_magazines.add(static_cast<Magazine*>(it));
        else delete it;
    }
}

void MainWindow::saveData()
{
    QList<LibraryItem*> items = allLoadedItems();
    LibraryUtils::saveToFile(m_dataFile, items);
}
