// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#include "libraryitem.h"

LibraryItem::LibraryItem(const QString &id, const QString &title, const QString &author)
    : m_id(id), m_title(title), m_author(author)
{}

QString LibraryItem::id() const { return m_id; }
void LibraryItem::setId(const QString &id) { m_id = id; }

QString LibraryItem::title() const { return m_title; }
void LibraryItem::setTitle(const QString &title) { m_title = title; }

QString LibraryItem::author() const { return m_author; }
void LibraryItem::setAuthor(const QString &author) { m_author = author; }

bool LibraryItem::isBorrowed() const { return m_borrowed; }
void LibraryItem::setBorrowed(bool borrowed) { m_borrowed = borrowed; }
