// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#ifndef BOOK_H
#define BOOK_H

#include "libraryitem.h"

class Book : public LibraryItem
{
public:
    Book() = default;
    Book(const QString &id, const QString &title, const QString &author, const QString &genre);

    QString genre() const;
    void setGenre(const QString &genre);

    QString displayInfo() const override;
    QString typeName() const override;

private:
    QString m_genre;
};

#endif // BOOK_H
