// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#include <QApplication>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
