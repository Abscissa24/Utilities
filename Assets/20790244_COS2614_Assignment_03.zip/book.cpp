// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#include "book.h"

Book::Book(const QString &id, const QString &title, const QString &author, const QString &genre)
    : LibraryItem(id, title, author), m_genre(genre)
{}

QString Book::genre() const { return m_genre; }
void Book::setGenre(const QString &genre) { m_genre = genre; }

QString Book::displayInfo() const
{
    return QString("Book | ID: %1 | Title: %2 | Author: %3 | Genre: %4 | %5")
            .arg(id(), title(), author(), m_genre, isBorrowed() ? "Borrowed" : "Available");
}

QString Book::typeName() const { return "Book"; }
