// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#include "magazine.h"

Magazine::Magazine(const QString &id, const QString &title, const QString &author, int issueNumber)
    : LibraryItem(id, title, author), m_issueNumber(issueNumber)
{}

int Magazine::issueNumber() const { return m_issueNumber; }
void Magazine::setIssueNumber(int issueNumber) { m_issueNumber = issueNumber; }

QString Magazine::displayInfo() const
{
    return QString("Magazine | ID: %1 | Title: %2 | Author: %3 | Issue: %4 | %5")
            .arg(id(), title(), author()).arg(m_issueNumber).arg(isBorrowed() ? "Borrowed" : "Available");
}

QString Magazine::typeName() const { return "Magazine"; }
