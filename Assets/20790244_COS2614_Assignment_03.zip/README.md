# Library Management (Qt/C++)
# Armiel Pillay
# Student Number: 20790244
# COS2614 Assignment 03

1. Open `LibraryManagement.pro` in Qt Creator
2. Build & Run (Desktop kit).

- Items are saved to `library_data.txt` next to the executable in a simple `|`-separated format.

- `libraryitem.*` — Base class with virtual interface.
- `book.*`, `magazine.*` — Derived classes.
- `storage.h` — Template container using `QList<T*>`.
- `libraryutils.*` — Save/load helpers (can be split to a static library if required).
- `mainwindow.*`, `main.cpp` — Qt Widgets GUI.

# USAGE

- You need to type a Book/Magazine ID, Title and Author FIRST!
- Then press ADD
- If you press add without having entered the above fields, nothing will happen!
