// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#ifndef STORAGE_H
#define STORAGE_H

#include <QList>
#include <functional>

// A simple generic storage for LibraryItem pointers.
// T is expected to inherit from LibraryItem.
template <typename T>
class Storage
{
public:
    Storage() = default;
    ~Storage() { clear(); }

    void add(T* item) { m_items.append(item); }
    bool removeById(const QString &id) {
        for (int i = 0; i < m_items.size(); ++i) {
            if (m_items[i]->id() == id) {
                delete m_items.takeAt(i);
                return true;
            }
        }
        return false;
    }
    T* findById(const QString &id) const {
        for (T* it : m_items) if (it->id() == id) return it;
        return nullptr;
    }

    QList<T*> items() const { return m_items; }

    void clear() { qDeleteAll(m_items); m_items.clear(); }

    // simple find with predicate
    T* findIf(std::function<bool(const T*)> pred) const {
        for (T* it : m_items) if (pred(it)) return it;
        return nullptr;
    }

private:
    QList<T*> m_items;
};

#endif // STORAGE_H
