// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#ifndef LIBRARYITEM_H
#define LIBRARYITEM_H

#include <QString>

class LibraryItem
{
public:
    LibraryItem() = default;
    LibraryItem(const QString &id, const QString &title, const QString &author);
    virtual ~LibraryItem() = default;

    // Encapsulation: private members with getters/setters
    QString id() const;
    void setId(const QString &id);

    QString title() const;
    void setTitle(const QString &title);

    QString author() const;
    void setAuthor(const QString &author);

    bool isBorrowed() const;
    void setBorrowed(bool borrowed);

    // Polymorphism
    virtual QString displayInfo() const = 0;
    virtual QString typeName() const = 0;

private:
    QString m_id;
    QString m_title;
    QString m_author;
    bool m_borrowed{false};
};

#endif // LIBRARYITEM_H
