// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#ifndef MAGAZINE_H
#define MAGAZINE_H

#include "libraryitem.h"

class Magazine : public LibraryItem
{
public:
    Magazine() = default;
    Magazine(const QString &id, const QString &title, const QString &author, int issueNumber);

    int issueNumber() const;
    void setIssueNumber(int issueNumber);

    QString displayInfo() const override;
    QString typeName() const override;

private:
    int m_issueNumber{0};
};

#endif // MAGAZINE_H
