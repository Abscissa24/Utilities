// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#include "libraryutils.h"
#include "book.h"
#include "magazine.h"
#include <QFile>
#include <QTextStream>

QString LibraryUtils::escapeField(const QString &s) {
    QString out = s;
    out.replace("|", "&#124;"); // minimal escaping
    return out;
}
QString LibraryUtils::unescapeField(const QString &s) {
    QString out = s;
    out.replace("&#124;", "|");
    return out;
}

bool LibraryUtils::saveToFile(const QString &filename, const QList<LibraryItem*> &items) {
    QFile f(filename);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) return false;
    QTextStream ts(&f);
    for (LibraryItem* it : items) {
        QString type = it->typeName();
        QString id = escapeField(it->id());
        QString title = escapeField(it->title());
        QString author = escapeField(it->author());
        QString extra;
        if (type == "Book") {
            Book* b = static_cast<Book*>(it);
            extra = escapeField(b->genre());
        } else if (type == "Magazine") {
            Magazine* m = static_cast<Magazine*>(it);
            extra = QString::number(m->issueNumber());
        }
        QString borrowed = it->isBorrowed() ? "1" : "0";
        ts << type << "|" << id << "|" << title << "|" << author << "|" << extra << "|" << borrowed << "\n";
    }
    f.close();
    return true;
}

QList<LibraryItem*> LibraryUtils::loadFromFile(const QString &filename) {
    QList<LibraryItem*> list;
    QFile f(filename);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) return list;
    QTextStream ts(&f);
    while (!ts.atEnd()) {
        QString line = ts.readLine().trimmed();
        if (line.isEmpty()) continue;
        QStringList parts = line.split("|");
        if (parts.size() < 6) continue;
        QString type = parts[0];
        QString id = unescapeField(parts[1]);
        QString title = unescapeField(parts[2]);
        QString author = unescapeField(parts[3]);
        QString extra = parts[4];
        bool borrowed = (parts[5] == "1");
        if (type == "Book") {
            Book* b = new Book(id, title, author, unescapeField(extra));
            b->setBorrowed(borrowed);
            list.append(b);
        } else if (type == "Magazine") {
            Magazine* m = new Magazine(id, title, author, extra.toInt());
            m->setBorrowed(borrowed);
            list.append(m);
        }
    }
    f.close();
    return list;
}
