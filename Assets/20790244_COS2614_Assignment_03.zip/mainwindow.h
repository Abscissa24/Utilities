// Armiel Pillay
// Student Number: 20790244
// COS2614 Assignment 03

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStandardItemModel>
#include <QSortFilterProxyModel>
#include "storage.h"
#include "libraryitem.h"
#include "book.h"
#include "magazine.h"

QT_BEGIN_NAMESPACE
class QListView;
class QPushButton;
class QLineEdit;
class QLabel;
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onAddBook();
    void onAddMagazine();
    void onSearchTextChanged(const QString &text);
    void onItemActivated(const QModelIndex &index);
    void onBorrowReturn();

private:
    void setupUi();
    void refreshModel();
    QString itemDisplayText(LibraryItem* it) const;

    // storage containers
    Storage<Book> m_books;
    Storage<Magazine> m_magazines;

    // model & view
    QStandardItemModel *m_model;
    QSortFilterProxyModel *m_proxy;

    // widgets
    QListView *m_listView;
    QLineEdit *m_searchEdit;
    QLineEdit *m_idEdit, *m_titleEdit, *m_authorEdit, *m_genreOrIssueEdit;
    QPushButton *m_addBookBtn, *m_addMagazineBtn, *m_borrowReturnBtn;
    QLabel *m_detailLabel;

    QString m_dataFile{"library_data.txt"};
    QList<LibraryItem*> allLoadedItems(); // helper to gather pointers for save/load
    void loadData();
    void saveData();
};

#endif // MAINWINDOW_H
